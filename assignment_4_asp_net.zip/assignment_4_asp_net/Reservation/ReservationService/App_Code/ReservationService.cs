﻿//  ReservationService.cs
// Airline reservation WCF web service.
using System.Linq;

using System;
using System.Collections.Generic;

using System.Text;
using System.Threading.Tasks;

public class ReservationService : IReservationService
{
    // create ticketsDB object to access Tickets database
    private TicketsDataContext ticketsDB = new TicketsDataContext();

    // checks database to determine whether matching seat is available
    public bool Reserve(string seatType, string classType)
    {
        //  LINQ query to find seats matching the parameters
        var result =
           from seat in ticketsDB.Seats
           where (seat.Taken == false) && (seat.SeatType == seatType)
              && (seat.SeatClass == classType)
           select seat;

        // get first available seat
        Seat firstAvailableSeat = result.FirstOrDefault();

        // if seat is available seats, mark it as taken
        if (firstAvailableSeat != null)
        {
            firstAvailableSeat.Taken = true; // mark the seat as taken
            ticketsDB.SubmitChanges(); // update 
            return true; // seat was reserved
        } // end if

        return false; // no seat was reserved
    } // end method Reserve
} // end class ReservationService


